Component({
  properties: {
    title: String,
    ver: Number,
    hor: Number
  },
  data: {
    style: 'margin: 10px 15px;'
  }
});

Page({
  handleGetuserinfo (event) {
    console.log(event)
  }
});
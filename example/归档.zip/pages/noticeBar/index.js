
Page({
  data: {
    text: "京东JD.COM-专业的综合网上购物商城，销售超数万品牌、4020万种商品，囊括家电、手机、电脑、母婴、服装等13大品类。",
    value1:1,
  },
  handleChange1 ({ detail }) {

  },
});